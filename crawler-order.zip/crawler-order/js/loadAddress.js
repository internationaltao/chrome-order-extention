



window.postMessage({cmd: 'loadAddressData', data: {}}, '*');