var addressMap;
// 监听来自content-script的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
{
	console.log('收到来自content-script的消息：');
	console.log(request, sender, sendResponse);
	if(request.greeting == 'queryAddressMap'){
		sendResponse(addressMap);
		return;
	}else{
		addressMap = request.greeting;
	}
	sendResponse('收到消息!' + JSON.stringify(request));
});

// 向content-script主动发送消息
function sendMessageToContentScript(message, callback)
{
	getCurrentTabId((tabId) =>
	{
		chrome.tabs.sendMessage(tabId, message, function(response)
		{
			if(callback) callback(response);
		});
	});
}
// 获取当前选项卡ID
function getCurrentTabId(callback)
{
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs)
	{
		if(callback) callback(tabs.length ? tabs[0].id: null);
	});
}

// 当前标签打开某个链接
function openUrlCurrentTab(url)
{
	getCurrentTabId(tabId => {
		chrome.tabs.update(tabId, {url: url});
	})
}

// 新标签打开某个链接
function openUrlNewTab(url)
{
	chrome.tabs.create({url: url});
}


// 预留一个方法给popup调用
function testBackground() {
	$.get('https://www.baidu.com', function(html){
		alert('跨域调用成功:'+html);
	});
}

// 订单抓取
function crawlerOrderData()
{
	alert('backgroup begin');
	// sendMessageToContentScript({cmd:'update_font_size', size: 42}, function(response){});
}
