function doClicks1(){
    //第一次点击操作
    var result = document.evaluate("//tr/td[6]//span[text() = '查看']", document, null, XPathResult.ANY_TYPE, null);
    var nodes = result.iterateNext(); //枚举第一个元素
    while (nodes){
        // 对 nodes 执行操作;
        nodes.click();
        nodes=result.iterateNext(); //枚举下一个元素
    }
}
for(var i = 0; i< 3;i++){
    console.log("点击波次数:"+i);
    doClicks1();
}